<?php
$test = "reboot";
exec($test,$array);
print_r($array);
?>